# Emulation of Do While loop

i=0
while True:
 print(i)
 i=i+1
 if(i%100==0):
  break