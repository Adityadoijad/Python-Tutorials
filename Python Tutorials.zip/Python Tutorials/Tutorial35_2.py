def welcome():
    print("welcome to the code")

if __name__=="__main__":
 welcome()

variable="this is variable in this code"