# FOR LOOP

for i in range(5):
    print(i+1)
print("\n")

name="AdityaDoijad"
for k in name:
    print(k)
    if (k== "a"):
     print("\n")
print("\n")


colours=["red","yellow","green","black"]
for colour in colours:
   print(colour)
   for k in colour:
      print(k)
print("\n")

for j in range(1,5):
   print(j)
print("\n")


''' 
Next Program is about step range in for loop(start,stop,step)
'''
for l in range(0,20,3):  
   print(l)