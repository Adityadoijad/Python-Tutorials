print("Hello world", "Aditya", 29_04_2005)
print(8)
print(13 * 9)
print("Bye")

